-- MariaDB dump 10.19  Distrib 10.5.12-MariaDB, for Linux (x86_64)
--
-- Host: mysql.hostinger.ro    Database: u574849695_22
-- ------------------------------------------------------
-- Server version	10.5.12-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Building`
--

DROP TABLE IF EXISTS `Building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Building` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Subject_id` int(11) NOT NULL,
  `Trainer_id` int(11) NOT NULL,
  `Category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Building_Category` (`Category_id`),
  KEY `Building_Subject` (`Subject_id`),
  KEY `Building_Trainer` (`Trainer_id`),
  CONSTRAINT `Building_Category` FOREIGN KEY (`Category_id`) REFERENCES `Category` (`id`),
  CONSTRAINT `Building_Subject` FOREIGN KEY (`Subject_id`) REFERENCES `Subject` (`id`),
  CONSTRAINT `Building_Trainer` FOREIGN KEY (`Trainer_id`) REFERENCES `Trainer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Building`
--

LOCK TABLES `Building` WRITE;
/*!40000 ALTER TABLE `Building` DISABLE KEYS */;
INSERT INTO `Building` VALUES (1,1,1,1),(2,2,2,2),(3,3,3,3),(4,1,4,4),(5,2,5,5),(6,3,6,6),(7,1,7,7),(8,2,1,8),(9,3,2,9),(10,1,3,10),(11,2,4,11),(12,3,5,12),(13,1,6,13),(14,2,7,14),(15,3,1,15),(16,1,2,16),(17,2,3,17),(18,3,4,18),(19,1,5,19),(20,2,6,20),(21,3,7,21),(22,1,1,22),(23,2,2,23),(24,3,3,24),(25,1,4,25);
/*!40000 ALTER TABLE `Building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Building_Schedule`
--

DROP TABLE IF EXISTS `Building_Schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Building_Schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Building_id` int(11) NOT NULL,
  `Schedule_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Building_association_2` (`Building_id`),
  KEY `Schedule_association_2` (`Schedule_id`),
  CONSTRAINT `Building_association_2` FOREIGN KEY (`Building_id`) REFERENCES `Building` (`id`),
  CONSTRAINT `Schedule_association_2` FOREIGN KEY (`Schedule_id`) REFERENCES `Schedule` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Building_Schedule`
--

LOCK TABLES `Building_Schedule` WRITE;
/*!40000 ALTER TABLE `Building_Schedule` DISABLE KEYS */;
INSERT INTO `Building_Schedule` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5),(6,6,6),(7,7,7),(8,8,8),(9,9,9),(10,10,10),(11,11,11),(12,12,12),(13,13,13),(14,14,14),(15,15,15),(16,16,16),(17,17,17),(18,18,18),(19,19,19),(20,20,20),(21,21,21),(22,22,22),(23,23,23),(24,24,24),(25,25,25);
/*!40000 ALTER TABLE `Building_Schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Category`
--

DROP TABLE IF EXISTS `Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('A','P','M') COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacity` enum('Low','Medium','Full') COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_car` enum('Private','Public','Both') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category`
--

LOCK TABLES `Category` WRITE;
/*!40000 ALTER TABLE `Category` DISABLE KEYS */;
INSERT INTO `Category` VALUES (1,'P','Medium','Public'),(2,'M','Low','Public'),(3,'P','Full','Public'),(4,'P','Full','Private'),(5,'M','Full','Both'),(6,'P','Full','Both'),(7,'P','Medium','Both'),(8,'A','Low','Private'),(9,'P','Low','Public'),(10,'A','Medium','Both'),(11,'M','Full','Both'),(12,'P','Low','Private'),(13,'M','Full','Both'),(14,'A','Full','Both'),(15,'M','Medium','Both'),(16,'M','Low','Private'),(17,'A','Low','Both'),(18,'A','Full','Both'),(19,'A','Medium','Private'),(20,'P','Low','Public'),(21,'P','Medium','Both'),(22,'M','Full','Public'),(23,'M','Medium','Both'),(24,'P','Full','Public'),(25,'M','Low','Private'),(26,'A','Medium','Private'),(27,'M','Full','Both');
/*!40000 ALTER TABLE `Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Certificate`
--

DROP TABLE IF EXISTS `Certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Certificate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Category_id` int(11) NOT NULL,
  `Company_id` int(11) NOT NULL,
  `Student_Building_id` int(11) NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Certificate_idx_1` (`id`) USING BTREE,
  KEY `Certificate_Category` (`Category_id`),
  KEY `Certificate_Company` (`Company_id`),
  KEY `Certificate_association_1` (`Student_Building_id`),
  CONSTRAINT `Certificate_Category` FOREIGN KEY (`Category_id`) REFERENCES `Category` (`id`),
  CONSTRAINT `Certificate_Company` FOREIGN KEY (`Company_id`) REFERENCES `Company` (`id`),
  CONSTRAINT `Certificate_association_1` FOREIGN KEY (`Student_Building_id`) REFERENCES `Student_Building` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Certificate`
--

LOCK TABLES `Certificate` WRITE;
/*!40000 ALTER TABLE `Certificate` DISABLE KEYS */;
INSERT INTO `Certificate` VALUES (1,1,1,1,'Netherlands','2020-04-17'),(2,2,1,2,'France','2020-04-17'),(3,3,1,3,'France','2020-04-17'),(4,4,1,4,'France','2020-04-17'),(5,5,1,5,'Netherlands','2020-04-17'),(6,6,1,6,'France','2020-04-17'),(7,7,1,7,'France','2020-04-17'),(8,8,1,8,'France','2020-04-17'),(9,9,1,9,'Netherlands','2020-04-17'),(10,10,1,10,'Netherlands','2020-04-17'),(11,11,1,11,'France','2020-04-17'),(12,12,1,12,'France','2020-04-17'),(13,13,1,13,'France','2020-04-17'),(14,14,1,14,'France','2020-04-17'),(15,15,1,15,'Netherlands','2020-04-17'),(16,16,1,16,'France','2020-04-17'),(17,17,1,17,'Netherlands','2020-04-17'),(18,18,1,18,'France','2020-04-17'),(19,19,1,19,'France','2020-04-17'),(20,20,1,20,'France','2020-04-17'),(21,21,1,21,'Netherlands','2020-04-17'),(22,22,1,22,'France','2020-04-17'),(23,23,1,23,'Netherlands','2020-04-17'),(24,24,1,24,'Netherlands','2020-04-17'),(25,25,1,25,'France','2020-04-17'),(26,26,1,26,'Netherlands','2020-04-17'),(27,27,1,27,'Netherlands','2020-04-17'),(28,1,1,28,'Netherlands','2020-04-17'),(29,2,1,29,'France','2020-04-17'),(30,3,1,30,'Netherlands','2020-04-17'),(31,4,1,31,'Netherlands','2020-04-17'),(32,5,1,32,'Netherlands','2020-04-17'),(33,6,1,33,'France','2020-04-17'),(34,7,1,34,'France','2020-04-17'),(35,8,1,35,'Netherlands','2020-04-17'),(36,9,1,36,'Netherlands','2020-04-17'),(37,10,1,37,'Netherlands','2020-04-17'),(38,11,1,38,'France','2020-04-17'),(39,12,1,39,'Netherlands','2020-04-17'),(40,13,1,40,'France','2020-04-17'),(41,14,1,41,'France','2020-04-17'),(42,15,1,42,'France','2020-04-17'),(43,16,1,43,'France','2020-04-17'),(44,17,1,44,'Netherlands','2020-04-17'),(45,18,1,45,'Netherlands','2020-04-17'),(46,19,1,46,'France','2020-04-17'),(47,20,1,47,'France','2020-04-17'),(48,21,1,48,'Netherlands','2020-04-17'),(49,22,1,49,'Netherlands','2020-04-17'),(50,23,1,50,'France','2020-04-17'),(51,24,1,51,'Netherlands','2020-04-17'),(52,25,1,52,'Netherlands','2020-04-17'),(53,26,1,53,'Netherlands','2020-04-17'),(54,27,1,54,'France','2020-04-17'),(55,1,1,55,'Netherlands','2020-04-17'),(56,2,1,56,'Netherlands','2020-04-17'),(57,3,1,57,'Netherlands','2020-04-17'),(58,4,1,58,'France','2020-04-17'),(59,5,1,59,'France','2020-04-17'),(60,6,1,60,'France','2020-04-17'),(61,7,1,61,'France','2020-04-17'),(62,8,1,62,'France','2020-04-17'),(63,9,1,63,'Netherlands','2020-04-17'),(64,10,1,64,'France','2020-04-17'),(65,11,1,65,'France','2020-04-17'),(66,12,1,66,'France','2020-04-17'),(67,13,1,67,'Netherlands','2020-04-17'),(68,14,1,68,'France','2020-04-17'),(69,15,1,69,'France','2020-04-17'),(70,16,1,70,'France','2020-04-17'),(71,17,1,71,'France','2020-04-17'),(72,18,1,72,'France','2020-04-17'),(73,19,1,73,'Netherlands','2020-04-17'),(74,20,1,74,'Netherlands','2020-04-17'),(75,21,1,75,'Netherlands','2020-04-17'),(76,22,1,76,'Netherlands','2020-04-17'),(77,23,1,77,'France','2020-04-17'),(78,24,1,78,'Netherlands','2020-04-17'),(79,25,1,79,'France','2020-04-17'),(80,26,1,80,'Netherlands','2020-04-17'),(81,27,1,81,'France','2020-04-17'),(82,1,1,82,'Netherlands','2020-04-17'),(83,2,1,83,'Netherlands','2020-04-17'),(84,3,1,84,'France','2020-04-17'),(85,4,1,85,'France','2020-04-17'),(86,5,1,86,'France','2020-04-17'),(87,6,1,87,'France','2020-04-17'),(88,7,1,88,'France','2020-04-17'),(89,8,1,89,'France','2020-04-17'),(90,9,1,90,'France','2020-04-17'),(91,10,1,91,'Netherlands','2020-04-17'),(92,11,1,92,'France','2020-04-17'),(93,12,1,93,'Netherlands','2020-04-17'),(94,13,1,94,'France','2020-04-17'),(95,14,1,95,'France','2020-04-17'),(96,15,1,96,'Netherlands','2020-04-17'),(97,16,1,97,'France','2020-04-17'),(98,17,1,98,'France','2020-04-17'),(99,18,1,99,'Netherlands','2020-04-17'),(100,19,1,100,'Netherlands','2020-04-17'),(101,20,1,101,'France','2020-04-17'),(102,21,1,102,'France','2020-04-17'),(103,22,1,103,'France','2020-04-17'),(104,23,1,104,'France','2020-04-17'),(105,24,1,105,'France','2020-04-17'),(106,25,1,106,'France','2020-04-17'),(107,26,1,107,'France','2020-04-17'),(108,27,1,108,'France','2020-04-17'),(109,1,1,109,'France','2020-04-17'),(110,2,1,110,'France','2020-04-17'),(111,3,1,111,'France','2020-04-17'),(112,4,1,112,'France','2020-04-17'),(113,5,1,113,'Netherlands','2020-04-17'),(114,6,1,114,'Netherlands','2020-04-17'),(115,7,1,115,'Netherlands','2020-04-17'),(116,8,1,116,'France','2020-04-17'),(117,9,1,117,'Netherlands','2020-04-17'),(118,10,1,118,'France','2020-04-17'),(119,11,1,119,'Netherlands','2020-04-17'),(120,12,1,120,'France','2020-04-17'),(121,13,1,121,'Netherlands','2020-04-17'),(122,14,1,122,'France','2020-04-17'),(123,15,1,123,'France','2020-04-17'),(124,16,1,124,'Netherlands','2020-04-17'),(125,17,1,125,'Netherlands','2020-04-17'),(126,18,1,126,'Netherlands','2020-04-17'),(127,19,1,127,'Netherlands','2020-04-17'),(128,20,1,128,'France','2020-04-17'),(129,21,1,129,'France','2020-04-17'),(130,22,1,130,'France','2020-04-17'),(131,23,1,131,'France','2020-04-17'),(132,24,1,132,'France','2020-04-17'),(133,25,1,133,'Netherlands','2020-04-17'),(134,26,1,134,'France','2020-04-17'),(135,27,1,135,'Netherlands','2020-04-17'),(136,1,1,136,'France','2020-04-17'),(137,2,1,137,'France','2020-04-17'),(138,3,1,138,'France','2020-04-17'),(139,4,1,139,'Netherlands','2020-04-17'),(140,5,1,140,'Netherlands','2020-04-17'),(141,6,1,141,'France','2020-04-17'),(142,7,1,142,'Netherlands','2020-04-17'),(143,8,1,143,'France','2020-04-17'),(144,9,1,144,'France','2020-04-17'),(145,10,1,145,'France','2020-04-17'),(146,11,1,146,'Netherlands','2020-04-17'),(147,12,1,147,'Netherlands','2020-04-17'),(148,13,1,148,'Netherlands','2020-04-17'),(149,14,1,149,'Netherlands','2020-04-17'),(150,15,1,150,'Netherlands','2020-04-17'),(151,16,1,151,'France','2020-04-17'),(152,17,1,152,'France','2020-04-17'),(153,18,1,153,'France','2020-04-17'),(154,19,1,154,'Netherlands','2020-04-17'),(155,20,1,155,'France','2020-04-17'),(156,21,1,156,'France','2020-04-17'),(157,22,1,157,'France','2020-04-17'),(158,23,1,158,'Netherlands','2020-04-17'),(159,24,1,159,'Netherlands','2020-04-17'),(160,25,1,160,'Netherlands','2020-04-17'),(161,26,1,161,'France','2020-04-17'),(162,27,1,162,'France','2020-04-17'),(163,1,1,163,'France','2020-04-17'),(164,2,1,164,'France','2020-04-17'),(165,3,1,165,'Netherlands','2020-04-17'),(166,4,1,166,'France','2020-04-17'),(167,5,1,167,'Netherlands','2020-04-17'),(168,6,1,168,'Netherlands','2020-04-17'),(169,7,1,169,'France','2020-04-17'),(170,8,1,170,'France','2020-04-17'),(171,9,1,171,'France','2020-04-17'),(172,10,1,172,'France','2020-04-17'),(173,11,1,173,'Netherlands','2020-04-17'),(174,12,1,174,'Netherlands','2020-04-17'),(175,13,1,175,'Netherlands','2020-04-17'),(176,14,1,176,'Netherlands','2020-04-17'),(177,15,1,177,'France','2020-04-17'),(178,16,1,178,'France','2020-04-17'),(179,17,1,179,'France','2020-04-17'),(180,18,1,180,'Netherlands','2020-04-17'),(181,19,1,181,'Netherlands','2020-04-17'),(182,20,1,182,'France','2020-04-17'),(183,21,1,183,'Netherlands','2020-04-17'),(184,22,1,184,'Netherlands','2020-04-17'),(185,23,1,185,'France','2020-04-17'),(186,24,1,186,'Netherlands','2020-04-17'),(187,25,1,187,'Netherlands','2020-04-17'),(188,26,1,188,'France','2020-04-17'),(189,27,1,189,'Netherlands','2020-04-17'),(190,1,1,190,'France','2020-04-17'),(191,2,1,191,'Netherlands','2020-04-17'),(192,3,1,192,'Netherlands','2020-04-17'),(193,4,1,193,'Netherlands','2020-04-17'),(194,5,1,194,'France','2020-04-17'),(195,6,1,195,'Netherlands','2020-04-17'),(196,7,1,196,'Netherlands','2020-04-17'),(197,8,1,197,'France','2020-04-17'),(198,9,1,198,'Netherlands','2020-04-17'),(199,10,1,199,'Netherlands','2020-04-17'),(200,11,1,200,'Netherlands','2020-04-17');
/*!40000 ALTER TABLE `Certificate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Company`
--

DROP TABLE IF EXISTS `Company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Company`
--

LOCK TABLES `Company` WRITE;
/*!40000 ALTER TABLE `Company` DISABLE KEYS */;
INSERT INTO `Company` VALUES (1,'Maggio Ltd',39,'078 Jermain View\nLake Dorthastad, VT 82710');
/*!40000 ALTER TABLE `Company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Data_Maintenance`
--

DROP TABLE IF EXISTS `Data_Maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Data_Maintenance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `Vehicle_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Data_Maintenance_Vehicle` (`Vehicle_id`),
  CONSTRAINT `Data_Maintenance_Vehicle` FOREIGN KEY (`Vehicle_id`) REFERENCES `Vehicle` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Data_Maintenance`
--

LOCK TABLES `Data_Maintenance` WRITE;
/*!40000 ALTER TABLE `Data_Maintenance` DISABLE KEYS */;
INSERT INTO `Data_Maintenance` VALUES (1,'2003-01-01',1),(2,'2003-01-01',2),(3,'2003-01-01',3),(4,'2003-01-01',4),(5,'2003-01-01',5),(6,'2003-01-01',6),(7,'2003-01-01',7),(8,'2003-01-01',8),(9,'2003-01-01',9),(10,'2003-01-01',10),(11,'2003-01-01',11),(12,'2003-01-01',12),(13,'2003-01-01',13),(14,'2003-01-01',14),(15,'2003-01-01',15),(16,'2003-01-01',16),(17,'2003-01-01',17),(18,'2003-01-01',18),(19,'2003-01-01',19),(20,'2003-01-01',20),(21,'2003-01-01',21),(22,'2003-01-01',22),(23,'2003-01-01',23),(24,'2003-01-01',24),(25,'2003-01-01',25),(26,'2003-01-01',26),(27,'2003-01-01',27),(28,'2003-01-01',28),(29,'2003-01-01',29),(30,'2003-01-01',30),(31,'2003-01-01',31),(32,'2003-01-01',32),(33,'2003-01-01',33),(34,'2003-01-01',34),(35,'2003-01-01',35),(36,'2003-01-01',36),(37,'2003-01-01',37),(38,'2003-01-01',38),(39,'2003-01-01',39),(40,'2003-01-01',40),(41,'2003-01-01',41),(42,'2003-01-01',42),(43,'2003-01-01',43),(44,'2003-01-01',44),(45,'2003-01-01',45),(46,'2003-01-01',46),(47,'2003-01-01',47),(48,'2003-01-01',48),(49,'2003-01-01',49),(50,'2003-01-01',50),(51,'2003-01-01',1),(52,'2003-01-01',2),(53,'2003-01-01',3),(54,'2003-01-01',4),(55,'2003-01-01',5),(56,'2003-01-01',6),(57,'2003-01-01',7),(58,'2003-01-01',8),(59,'2003-01-01',9),(60,'2003-01-01',10),(61,'2003-01-01',11),(62,'2003-01-01',12),(63,'2003-01-01',13),(64,'2003-01-01',14),(65,'2003-01-01',15),(66,'2003-01-01',16),(67,'2003-01-01',17),(68,'2003-01-01',18),(69,'2003-01-01',19),(70,'2003-01-01',20),(71,'2003-01-01',21),(72,'2003-01-01',22),(73,'2003-01-01',23),(74,'2003-01-01',24),(75,'2003-01-01',25),(76,'2003-01-01',26),(77,'2003-01-01',27),(78,'2003-01-01',28),(79,'2003-01-01',29),(80,'2003-01-01',30),(81,'2003-01-01',31),(82,'2003-01-01',32),(83,'2003-01-01',33),(84,'2003-01-01',34),(85,'2003-01-01',35),(86,'2003-01-01',36),(87,'2003-01-01',37),(88,'2003-01-01',38),(89,'2003-01-01',39),(90,'2003-01-01',40),(91,'2003-01-01',41),(92,'2003-01-01',42),(93,'2003-01-01',43),(94,'2003-01-01',44),(95,'2003-01-01',45),(96,'2003-01-01',46),(97,'2003-01-01',47),(98,'2003-01-01',48),(99,'2003-01-01',49),(100,'2003-01-01',50);
/*!40000 ALTER TABLE `Data_Maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Note_History`
--

DROP TABLE IF EXISTS `Note_History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Note_History` (
  `name_student` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name_student` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int(11) NOT NULL,
  `name_subject` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_subject` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_trainer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name_trainer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Note_History`
--

LOCK TABLES `Note_History` WRITE;
/*!40000 ALTER TABLE `Note_History` DISABLE KEYS */;
/*!40000 ALTER TABLE `Note_History` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Schedule`
--

DROP TABLE IF EXISTS `Schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Schedule`
--

LOCK TABLES `Schedule` WRITE;
/*!40000 ALTER TABLE `Schedule` DISABLE KEYS */;
INSERT INTO `Schedule` VALUES (1,'03:57:33'),(2,'12:52:59'),(3,'11:56:17'),(4,'12:17:26'),(5,'03:23:36'),(6,'11:51:03'),(7,'19:14:59'),(8,'09:39:28'),(9,'02:33:46'),(10,'02:04:12'),(11,'03:45:55'),(12,'20:16:36'),(13,'16:35:16'),(14,'11:25:06'),(15,'19:00:24'),(16,'20:12:56'),(17,'05:25:32'),(18,'02:35:34'),(19,'10:27:57'),(20,'18:11:13'),(21,'23:39:46'),(22,'21:45:15'),(23,'12:17:24'),(24,'12:18:21'),(25,'02:59:57'),(26,'15:06:10'),(27,'15:23:37');
/*!40000 ALTER TABLE `Schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Student`
--

DROP TABLE IF EXISTS `Student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `phone` int(11) NOT NULL,
  `gender` enum('F','M') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Student` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Student`
--

LOCK TABLES `Student` WRITE;
/*!40000 ALTER TABLE `Student` DISABLE KEYS */;
INSERT INTO `Student` VALUES (1,'Henriette','Price',15,1,'F'),(2,'Tiffany','Rau',18,407713986,'M'),(3,'Willis','Sporer',16,581,'M'),(4,'Maye','Mosciski',15,0,'F'),(5,'Kadin','Olson',17,683,'M'),(6,'Jaqueline','Green',17,64,'M'),(7,'Jillian','Lindgren',15,0,'F'),(8,'Anabel','Lakin',17,82,'M'),(9,'Claudia','Cruickshank',18,217847,'M'),(10,'Erich','Barrows',17,1,'F'),(11,'Stanford','Raynor',16,921,'M'),(12,'Terrell','Ortiz',15,590,'M'),(13,'Alba','Connelly',18,0,'F'),(14,'Salvatore','Skiles',17,2147483647,'M'),(15,'Declan','Swift',16,485718,'M'),(16,'Bradley','Hudson',18,0,'M'),(17,'Kenyatta','Cummerata',16,64,'F'),(18,'Abbigail','Hoeger',16,0,'M'),(19,'Reanna','Gutmann',16,2147483647,'F'),(20,'Marietta','Cummerata',18,2124673442,'M'),(21,'Elaina','Homenick',18,861,'F'),(22,'Jules','Hermiston',15,46,'M'),(23,'Phoebe','Heller',15,1,'M'),(24,'Lysanne','Tromp',17,480,'M'),(25,'Walker','Beer',17,0,'F'),(26,'Mylene','Lowe',18,784,'M'),(27,'Stacy','Boyer',18,627974,'M'),(28,'Jefferey','Medhurst',15,950371,'M'),(29,'Frankie','Lakin',18,87,'F'),(30,'Claire','Flatley',18,1,'F'),(31,'Kailey','Stroman',17,0,'F'),(32,'Ayla','Littel',18,1,'M'),(33,'Mylene','Schulist',18,1,'M'),(34,'Pauline','Lehner',16,845,'F'),(35,'Molly','Walker',16,273,'F'),(36,'Sallie','Koss',15,1,'M'),(37,'Rosie','Wiegand',15,0,'F'),(38,'Clare','Howe',18,931,'F'),(39,'Burnice','Herman',18,2147483647,'M'),(40,'Ellie','Runolfsdottir',15,0,'M'),(41,'Vern','Schmidt',15,305,'M'),(42,'Jaleel','Durgan',17,1,'F'),(43,'Sarah','Dietrich',16,0,'M'),(44,'Lois','Runolfsson',18,0,'M'),(45,'Annabell','Abernathy',18,72,'M'),(46,'Alva','Mohr',17,108593,'M'),(47,'Terrence','Runte',15,689988,'F'),(48,'Keshawn','Volkman',18,6,'M'),(49,'Ova','Hoeger',17,371,'F'),(50,'Rhiannon','Mitchell',17,0,'F'),(51,'Earl','Gottlieb',16,587849,'F'),(52,'Jeramie','Wolf',15,1,'M'),(53,'Brandon','Bruen',15,1,'M'),(54,'Geovany','Pouros',16,1,'F'),(55,'Allan','Pollich',15,0,'F'),(56,'Chad','Labadie',18,1,'M'),(57,'Curt','Grimes',16,1,'M'),(58,'Elwin','Feest',18,449,'F'),(59,'Aubree','Zboncak',18,169,'M'),(60,'Vince','Hamill',15,0,'M'),(61,'Watson','Heaney',18,0,'M'),(62,'Della','Feeney',18,186426,'F'),(63,'Kayden','West',15,54,'M'),(64,'Franco','Simonis',16,319409,'F'),(65,'Lulu','Moen',15,28,'M'),(66,'Warren','Marquardt',15,2147483647,'M'),(67,'Brent','Renner',18,1,'M'),(68,'Bradford','Hayes',17,65281,'F'),(69,'Elizabeth','King',15,171767,'M'),(70,'Jaunita','D\'Amore',18,1,'F'),(71,'Leonardo','Kutch',18,2147483647,'F'),(72,'Verda','Gutmann',16,0,'F'),(73,'Juliana','Luettgen',15,1,'F'),(74,'Deangelo','Kessler',18,0,'F'),(75,'Evans','Effertz',17,0,'M'),(76,'Albin','Pacocha',17,0,'M'),(77,'Dustin','Kshlerin',17,0,'F'),(78,'Mazie','Lind',16,383746,'M'),(79,'Alena','Larson',18,2147483647,'F'),(80,'Vern','Feil',17,11,'M'),(81,'Cydney','Collins',18,2147483647,'F'),(82,'Marjolaine','Sawayn',17,1,'M'),(83,'Raphaelle','Roob',15,0,'M'),(84,'Adolf','Stracke',15,1,'F'),(85,'Dusty','Friesen',15,16,'M'),(86,'Sabryna','Ryan',15,226,'M'),(87,'Orie','Johns',18,0,'M'),(88,'Jessika','Kohler',15,1,'F'),(89,'Cathryn','Mitchell',17,0,'M'),(90,'Jewell','Walker',17,411,'F'),(91,'Teresa','Erdman',18,0,'F'),(92,'Kaylin','Smitham',18,611,'F'),(93,'Kevon','Schmidt',16,1,'F'),(94,'Maud','Douglas',16,925,'M'),(95,'Eino','Stamm',15,1,'F'),(96,'Napoleon','Toy',15,54,'M'),(97,'Leanne','Sporer',17,77480,'F'),(98,'Gage','Franecki',17,0,'F'),(99,'Savanna','Shanahan',16,92,'F'),(100,'Mariela','Gleason',17,374,'F'),(101,'Jesse','McCullough',17,1,'M'),(102,'Kaden','Braun',18,36430,'M'),(103,'Sydni','Nitzsche',18,89,'F'),(104,'Andreane','Pfannerstill',17,0,'F'),(105,'Kathlyn','Schaden',15,0,'M'),(106,'Cordell','Gaylord',18,1,'F'),(107,'Kody','O\'Reilly',18,1,'M'),(108,'Delia','Nolan',16,543,'F'),(109,'Sigurd','Gottlieb',15,0,'F'),(110,'Jordi','Stokes',15,563412,'M'),(111,'Henri','Aufderhar',17,2147483647,'F'),(112,'Rhett','Carroll',18,925,'F'),(113,'Maribel','Wisoky',18,737,'F'),(114,'Rasheed','Reinger',18,14,'F'),(115,'Leatha','Oberbrunner',15,1,'M'),(116,'Junior','Lind',18,715,'M'),(117,'Maud','Gleichner',18,0,'F'),(118,'Gloria','Mann',17,571243,'M'),(119,'Buford','Shanahan',17,769,'M'),(120,'Lamont','Jacobi',18,96714,'F'),(121,'Sam','Daugherty',15,0,'M'),(122,'Kenton','Herman',17,916465,'F'),(123,'Guadalupe','Lockman',18,97,'F'),(124,'Gene','Braun',16,19360,'M'),(125,'Gunnar','Medhurst',17,0,'M'),(126,'Stevie','Metz',18,1,'F'),(127,'Hassie','Wyman',18,85,'M'),(128,'Eleanore','Hane',16,47427,'F'),(129,'Lowell','Wuckert',18,227990,'F'),(130,'Cortez','Hudson',16,683512,'M'),(131,'Selmer','Tremblay',15,144,'F'),(132,'Alysa','Goodwin',18,2147483647,'F'),(133,'Madelyn','Luettgen',16,1,'M'),(134,'Ada','Kiehn',17,2147483647,'M'),(135,'Emelie','Borer',18,338,'F'),(136,'Penelope','Little',15,878426,'M'),(137,'Tyreek','Stiedemann',17,837,'F'),(138,'Harrison','Heller',17,38,'F'),(139,'Faustino','Daugherty',18,212,'M'),(140,'Izabella','Nader',16,1,'F'),(141,'Rahul','Kerluke',15,1,'F'),(142,'Jannie','Prosacco',17,6964,'M'),(143,'Tito','Heidenreich',15,0,'M'),(144,'Katherine','Mitchell',15,161974,'M'),(145,'Luna','Sawayn',17,1,'M'),(146,'Flossie','Schoen',16,1,'F'),(147,'Clyde','Lind',16,36,'F'),(148,'Vincenza','O\'Kon',18,1,'F'),(149,'Avis','Blanda',18,1,'M'),(150,'Judson','Bashirian',18,536,'M'),(151,'Fanny','Raynor',16,32,'M'),(152,'Trystan','Quigley',18,0,'F'),(153,'Marta','Keebler',18,248,'M'),(154,'Mazie','Lemke',16,500,'M'),(155,'Silas','Zemlak',17,475,'M'),(156,'Mckenzie','Koss',15,0,'M'),(157,'Lula','Legros',15,71,'F'),(158,'Crystal','Mitchell',17,38858,'M'),(159,'Brenna','Hand',16,1,'F'),(160,'Katherine','Wilderman',15,0,'F'),(161,'Emmet','Weimann',17,0,'M'),(162,'Ezekiel','Padberg',16,1,'F'),(163,'Lydia','Kohler',16,604465,'M'),(164,'Chyna','Schmidt',17,0,'F'),(165,'Alfredo','Bernier',15,77,'F'),(166,'Reggie','Hackett',15,605374,'M'),(167,'Kacey','Towne',18,0,'M'),(168,'Jermain','Okuneva',16,326,'M'),(169,'Verda','Ledner',18,0,'M'),(170,'Aidan','Dickens',17,243,'M'),(171,'Mayra','Mitchell',15,493,'F'),(172,'Zakary','Dickens',16,0,'F'),(173,'Paolo','Frami',17,0,'F'),(174,'Wilfredo','Ankunding',16,2147483647,'M'),(175,'Idell','Little',18,1,'F'),(176,'Marcelino','Douglas',18,293463,'M'),(177,'Otto','Corwin',15,2147483647,'M'),(178,'Laurie','Skiles',16,1,'M'),(179,'Eliza','Bartoletti',15,516,'M'),(180,'Kristin','Kuhn',15,2147483647,'F'),(181,'Emery','Nolan',15,941,'M'),(182,'Candelario','Dickens',15,341308,'M'),(183,'Jailyn','McLaughlin',18,0,'M'),(184,'Nathanael','Daniel',15,2147483647,'F'),(185,'Annabell','Ziemann',17,1,'M'),(186,'Michelle','Grady',15,656,'M'),(187,'Ariane','Boehm',15,130,'M'),(188,'Anahi','Predovic',15,595568,'M'),(189,'Eusebio','Walter',17,92,'M'),(190,'Jacquelyn','Ledner',15,0,'M'),(191,'Madison','Heller',18,0,'F'),(192,'Orin','Ankunding',17,143,'F'),(193,'Cyril','Erdman',18,0,'F'),(194,'Miles','Feil',15,613,'F'),(195,'Sasha','Doyle',17,0,'M'),(196,'Gabriel','McGlynn',17,1,'F'),(197,'Marley','Grimes',16,2147483647,'F'),(198,'Pasquale','Stamm',17,22,'M'),(199,'Marshall','Schoen',17,360,'F'),(200,'Carrie','Wolf',15,827125,'M');
/*!40000 ALTER TABLE `Student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Student_Building`
--

DROP TABLE IF EXISTS `Student_Building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Student_Building` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Student_id` int(11) NOT NULL,
  `Building_id` int(11) NOT NULL,
  `inscription_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `Building_association_1` (`Building_id`),
  KEY `Student_association_1` (`Student_id`),
  CONSTRAINT `Building_association_1` FOREIGN KEY (`Building_id`) REFERENCES `Building` (`id`),
  CONSTRAINT `Student_association_1` FOREIGN KEY (`Student_id`) REFERENCES `Student` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Student_Building`
--

LOCK TABLES `Student_Building` WRITE;
/*!40000 ALTER TABLE `Student_Building` DISABLE KEYS */;
INSERT INTO `Student_Building` VALUES (1,1,1,'2020-12-05 06:34:30'),(2,2,2,'2022-03-08 13:42:54'),(3,3,3,'2022-08-09 23:32:16'),(4,4,4,'2022-08-14 10:20:40'),(5,5,5,'2022-07-15 05:50:43'),(6,6,6,'2021-12-09 02:04:01'),(7,7,7,'2020-05-28 13:45:17'),(8,8,8,'2021-08-19 06:19:42'),(9,9,9,'2021-03-03 03:29:01'),(10,10,10,'2021-09-20 20:51:01'),(11,11,11,'2022-05-09 09:39:12'),(12,12,12,'2021-06-20 02:09:54'),(13,13,13,'2022-04-23 13:01:30'),(14,14,14,'2020-10-18 19:47:45'),(15,15,15,'2022-06-20 13:01:26'),(16,16,16,'2022-02-23 13:41:21'),(17,17,17,'2021-09-29 07:12:03'),(18,18,18,'2022-08-08 05:04:43'),(19,19,19,'2020-05-18 09:44:28'),(20,20,20,'2022-01-15 21:25:33'),(21,21,21,'2020-07-12 07:07:43'),(22,22,22,'2020-06-27 07:15:19'),(23,23,23,'2020-08-03 09:02:14'),(24,24,24,'2022-04-11 19:42:03'),(25,25,25,'2021-01-21 02:31:22'),(26,26,1,'2022-03-06 20:21:13'),(27,27,2,'2021-01-26 22:30:53'),(28,28,3,'2022-02-02 13:49:44'),(29,29,4,'2021-03-10 13:59:47'),(30,30,5,'2020-08-09 19:49:24'),(31,31,6,'2022-10-01 10:11:35'),(32,32,7,'2022-04-18 16:03:02'),(33,33,8,'2021-09-04 01:55:51'),(34,34,9,'2022-04-20 13:50:07'),(35,35,10,'2022-06-09 13:28:22'),(36,36,11,'2021-09-17 21:41:46'),(37,37,12,'2022-10-07 20:08:10'),(38,38,13,'2022-09-17 06:39:15'),(39,39,14,'2021-07-14 14:18:55'),(40,40,15,'2020-10-19 00:18:18'),(41,41,16,'2022-03-09 21:26:31'),(42,42,17,'2020-05-16 00:41:47'),(43,43,18,'2021-11-12 10:25:41'),(44,44,19,'2020-06-11 17:49:18'),(45,45,20,'2021-02-11 02:01:43'),(46,46,21,'2021-01-13 14:30:26'),(47,47,22,'2020-05-19 15:37:40'),(48,48,23,'2021-03-06 09:13:47'),(49,49,24,'2022-04-05 21:34:56'),(50,50,25,'2021-03-08 08:43:05'),(51,51,1,'2020-11-15 22:23:46'),(52,52,2,'2022-11-12 06:33:59'),(53,53,3,'2021-04-29 21:41:00'),(54,54,4,'2021-12-30 19:34:55'),(55,55,5,'2020-05-13 00:05:23'),(56,56,6,'2020-06-10 16:23:33'),(57,57,7,'2021-11-10 01:45:30'),(58,58,8,'2022-11-16 14:43:40'),(59,59,9,'2022-07-27 19:28:26'),(60,60,10,'2021-08-31 21:23:44'),(61,61,11,'2022-03-09 17:39:34'),(62,62,12,'2020-12-09 15:54:45'),(63,63,13,'2022-07-25 02:02:28'),(64,64,14,'2021-10-29 00:51:06'),(65,65,15,'2021-03-13 02:44:49'),(66,66,16,'2021-01-13 21:42:19'),(67,67,17,'2022-11-17 02:21:11'),(68,68,18,'2022-01-08 16:59:41'),(69,69,19,'2021-12-23 15:01:17'),(70,70,20,'2020-04-17 06:55:59'),(71,71,21,'2020-08-12 15:48:12'),(72,72,22,'2020-04-27 05:29:37'),(73,73,23,'2021-07-30 18:20:24'),(74,74,24,'2021-03-24 14:46:09'),(75,75,25,'2021-01-27 23:01:22'),(76,76,1,'2020-09-04 16:16:30'),(77,77,2,'2020-10-19 23:20:10'),(78,78,3,'2022-01-30 16:16:19'),(79,79,4,'2020-12-18 12:36:57'),(80,80,5,'2020-07-21 08:13:04'),(81,81,6,'2020-07-06 14:54:18'),(82,82,7,'2020-06-11 00:09:33'),(83,83,8,'2020-12-02 00:38:37'),(84,84,9,'2021-05-26 09:06:36'),(85,85,10,'2022-12-09 02:20:51'),(86,86,11,'2022-01-28 19:44:35'),(87,87,12,'2020-12-08 08:56:24'),(88,88,13,'2021-06-29 16:54:19'),(89,89,14,'2021-12-13 04:20:42'),(90,90,15,'2022-02-14 16:54:37'),(91,91,16,'2021-04-13 01:49:16'),(92,92,17,'2020-12-05 09:33:06'),(93,93,18,'2021-02-18 10:03:39'),(94,94,19,'2021-07-13 00:15:24'),(95,95,20,'2022-09-29 14:00:56'),(96,96,21,'2021-11-27 06:48:53'),(97,97,22,'2020-05-29 09:26:44'),(98,98,23,'2022-05-20 22:59:20'),(99,99,24,'2022-03-03 19:08:32'),(100,100,25,'2021-01-10 20:07:35'),(101,101,1,'2020-09-25 23:42:18'),(102,102,2,'2021-11-12 10:32:25'),(103,103,3,'2022-12-10 05:42:32'),(104,104,4,'2022-10-28 10:03:43'),(105,105,5,'2020-12-17 18:26:16'),(106,106,6,'2022-04-16 01:27:12'),(107,107,7,'2022-07-22 19:07:58'),(108,108,8,'2020-08-01 06:07:16'),(109,109,9,'2022-02-23 12:58:30'),(110,110,10,'2022-11-25 03:17:01'),(111,111,11,'2022-05-22 04:07:42'),(112,112,12,'2020-12-31 16:10:12'),(113,113,13,'2022-07-25 16:09:13'),(114,114,14,'2022-06-28 15:01:45'),(115,115,15,'2021-09-03 10:35:35'),(116,116,16,'2020-10-24 14:15:39'),(117,117,17,'2021-08-31 18:28:25'),(118,118,18,'2022-04-14 15:39:28'),(119,119,19,'2022-09-29 06:01:25'),(120,120,20,'2021-01-11 02:02:30'),(121,121,21,'2022-08-08 01:26:12'),(122,122,22,'2022-11-16 08:27:47'),(123,123,23,'2021-01-24 04:42:00'),(124,124,24,'2020-12-29 17:41:22'),(125,125,25,'2021-03-12 03:30:24'),(126,126,1,'2022-12-07 10:46:57'),(127,127,2,'2022-11-07 11:12:24'),(128,128,3,'2022-10-04 17:51:58'),(129,129,4,'2021-01-28 22:55:22'),(130,130,5,'2020-06-21 20:24:47'),(131,131,6,'2020-09-08 11:27:32'),(132,132,7,'2021-04-20 05:19:17'),(133,133,8,'2022-01-26 20:41:52'),(134,134,9,'2021-02-20 13:22:04'),(135,135,10,'2021-01-25 02:44:08'),(136,136,11,'2022-08-12 17:37:22'),(137,137,12,'2021-03-18 07:23:57'),(138,138,13,'2020-06-15 02:36:22'),(139,139,14,'2021-04-09 22:49:24'),(140,140,15,'2022-04-17 22:48:36'),(141,141,16,'2021-03-03 06:56:55'),(142,142,17,'2022-10-20 01:28:41'),(143,143,18,'2021-07-07 10:36:09'),(144,144,19,'2020-08-27 21:26:34'),(145,145,20,'2022-01-19 20:34:22'),(146,146,21,'2021-12-27 01:38:47'),(147,147,22,'2022-05-16 03:46:49'),(148,148,23,'2021-11-19 03:20:51'),(149,149,24,'2021-09-30 06:26:04'),(150,150,25,'2021-01-22 15:01:54'),(151,151,1,'2020-10-23 19:08:43'),(152,152,2,'2021-08-28 02:55:24'),(153,153,3,'2021-07-30 13:35:33'),(154,154,4,'2021-04-03 21:08:55'),(155,155,5,'2022-01-28 13:35:09'),(156,156,6,'2022-05-01 14:39:24'),(157,157,7,'2021-04-28 10:04:10'),(158,158,8,'2022-07-08 06:53:37'),(159,159,9,'2021-01-15 23:00:33'),(160,160,10,'2022-08-18 10:50:58'),(161,161,11,'2022-05-16 21:04:16'),(162,162,12,'2021-08-13 02:16:51'),(163,163,13,'2020-07-27 13:03:03'),(164,164,14,'2022-09-29 05:28:31'),(165,165,15,'2022-04-29 18:25:55'),(166,166,16,'2022-02-16 13:32:40'),(167,167,17,'2020-09-07 15:15:23'),(168,168,18,'2020-12-22 15:40:44'),(169,169,19,'2022-11-10 17:26:57'),(170,170,20,'2022-07-15 00:47:00'),(171,171,21,'2020-04-26 07:35:48'),(172,172,22,'2020-08-07 03:05:11'),(173,173,23,'2021-04-07 18:17:44'),(174,174,24,'2022-05-28 22:16:23'),(175,175,25,'2022-06-02 00:15:39'),(176,176,1,'2021-10-23 06:01:01'),(177,177,2,'2022-09-14 10:46:05'),(178,178,3,'2020-11-23 00:33:49'),(179,179,4,'2022-09-30 12:11:19'),(180,180,5,'2021-11-03 20:55:07'),(181,181,6,'2021-06-15 01:17:42'),(182,182,7,'2022-04-09 10:25:25'),(183,183,8,'2022-11-08 13:57:11'),(184,184,9,'2022-04-25 07:20:41'),(185,185,10,'2022-08-11 01:51:07'),(186,186,11,'2022-07-09 13:26:48'),(187,187,12,'2022-02-14 11:12:52'),(188,188,13,'2021-03-25 01:26:30'),(189,189,14,'2020-05-11 07:15:46'),(190,190,15,'2020-12-10 06:38:43'),(191,191,16,'2020-10-29 13:59:19'),(192,192,17,'2020-07-27 15:42:29'),(193,193,18,'2022-05-01 06:39:18'),(194,194,19,'2022-10-30 14:25:30'),(195,195,20,'2022-03-11 14:19:12'),(196,196,21,'2020-07-28 03:20:47'),(197,197,22,'2022-04-02 10:30:51'),(198,198,23,'2021-08-05 07:49:11'),(199,199,24,'2021-08-27 16:40:10'),(200,200,25,'2021-05-04 10:46:32');
/*!40000 ALTER TABLE `Student_Building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Student_Note`
--

DROP TABLE IF EXISTS `Student_Note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Student_Note` (
  `Student_Building_id` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  KEY `Student_Note_Student_Building` (`Student_Building_id`),
  CONSTRAINT `Student_Note_Student_Building` FOREIGN KEY (`Student_Building_id`) REFERENCES `Student_Building` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Student_Note`
--

LOCK TABLES `Student_Note` WRITE;
/*!40000 ALTER TABLE `Student_Note` DISABLE KEYS */;
INSERT INTO `Student_Note` VALUES (1,79),(2,67),(3,20),(4,58),(5,67),(6,96),(7,43),(8,5),(9,18),(10,44),(11,90),(12,83),(13,33),(14,41),(15,71),(16,10),(17,46),(18,67),(19,16),(20,71),(21,96),(22,94),(23,73),(24,73),(25,73),(26,87),(27,31),(28,76),(29,53),(30,40),(31,24),(32,7),(33,61),(34,56),(35,1),(36,100),(37,87),(38,24),(39,17),(40,53),(41,13),(42,58),(43,18),(44,85),(45,59),(46,28),(47,77),(48,66),(49,66),(50,92),(51,9),(52,17),(53,47),(54,67),(55,87),(56,41),(57,72),(58,56),(59,73),(60,1),(61,5),(62,29),(63,82),(64,64),(65,10),(66,54),(67,85),(68,75),(69,91),(70,36),(71,26),(72,60),(73,45),(74,30),(75,40),(76,88),(77,36),(78,21),(79,75),(80,8),(81,64),(82,23),(83,82),(84,52),(85,40),(86,99),(87,58),(88,98),(89,38),(90,56),(91,56),(92,100),(93,53),(94,67),(95,47),(96,52),(97,99),(98,96),(99,5),(100,8),(101,13),(102,10),(103,61),(104,33),(105,14),(106,28),(107,57),(108,14),(109,58),(110,75),(111,52),(112,44),(113,34),(114,99),(115,34),(116,63),(117,21),(118,13),(119,78),(120,78),(121,71),(122,53),(123,10),(124,87),(125,42),(126,69),(127,69),(128,60),(129,3),(130,26),(131,92),(132,24),(133,58),(134,68),(135,41),(136,37),(137,75),(138,88),(139,35),(140,4),(141,40),(142,36),(143,34),(144,20),(145,73),(146,46),(147,46),(148,39),(149,2),(150,66),(151,33),(152,36),(153,57),(154,15),(155,70),(156,60),(157,31),(158,34),(159,57),(160,35),(161,55),(162,59),(163,57),(164,22),(165,1),(166,13),(167,45),(168,63),(169,30),(170,70),(171,86),(172,94),(173,10),(174,67),(175,94),(176,16),(177,7),(178,97),(179,21),(180,28),(181,46),(182,69),(183,61),(184,17),(185,39),(186,39),(187,49),(188,13),(189,61),(190,22),(191,85),(192,20),(193,18),(194,15),(195,99),(196,44),(197,77),(198,80),(199,56),(200,59),(1,76),(2,56),(3,28),(4,61),(5,70),(6,35),(7,75),(8,1),(9,19),(10,45),(11,77),(12,48),(13,53),(14,61),(15,98),(16,31),(17,4),(18,33),(19,49),(20,83),(21,6),(22,16),(23,81),(24,19),(25,81),(26,86),(27,37),(28,80),(29,37),(30,52),(31,3),(32,63),(33,53),(34,29),(35,1),(36,90),(37,53),(38,83),(39,87),(40,62),(41,37),(42,77),(43,24),(44,9),(45,73),(46,45),(47,20),(48,25),(49,56),(50,9),(51,58),(52,12),(53,15),(54,23),(55,52),(56,80),(57,100),(58,27),(59,75),(60,27),(61,98),(62,91),(63,54),(64,100),(65,72),(66,13),(67,46),(68,97),(69,31),(70,59),(71,59),(72,52),(73,98),(74,63),(75,65),(76,65),(77,90),(78,50),(79,31),(80,36),(81,5),(82,82),(83,96),(84,61),(85,25),(86,40),(87,100),(88,68),(89,75),(90,40),(91,13),(92,87),(93,34),(94,89),(95,53),(96,98),(97,57),(98,98),(99,40),(100,90),(101,33),(102,10),(103,75),(104,23),(105,52),(106,78),(107,99),(108,13),(109,39),(110,68),(111,92),(112,27),(113,13),(114,2),(115,60),(116,18),(117,99),(118,16),(119,29),(120,24),(121,7),(122,86),(123,84),(124,12),(125,35),(126,17),(127,26),(128,73),(129,69),(130,82),(131,3),(132,84),(133,57),(134,95),(135,80),(136,78),(137,52),(138,53),(139,64),(140,11),(141,53),(142,93),(143,46),(144,34),(145,57),(146,12),(147,0),(148,48),(149,59),(150,89),(151,6),(152,82),(153,11),(154,19),(155,79),(156,99),(157,44),(158,25),(159,82),(160,67),(161,75),(162,36),(163,0),(164,12),(165,39),(166,0),(167,4),(168,34),(169,100),(170,13),(171,55),(172,94),(173,54),(174,83),(175,10),(176,9),(177,76),(178,87),(179,52),(180,95),(181,21),(182,82),(183,35),(184,86),(185,11),(186,18),(187,71),(188,90),(189,87),(190,83),(191,90),(192,9),(193,8),(194,66),(195,71),(196,13),(197,90),(198,61),(199,74),(200,67);
/*!40000 ALTER TABLE `Student_Note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Subject`
--

DROP TABLE IF EXISTS `Subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `category` enum('Practice','Theory') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Subject`
--

LOCK TABLES `Subject` WRITE;
/*!40000 ALTER TABLE `Subject` DISABLE KEYS */;
INSERT INTO `Subject` VALUES (1,'traffic regulations',564,'Theory'),(2,'driving',590,'Practice'),(3,'automotive theory',549,'Theory');
/*!40000 ALTER TABLE `Subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Trainer`
--

DROP TABLE IF EXISTS `Trainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Trainer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `phone` int(11) NOT NULL,
  `gender` enum('F','M') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Trainer_idx_1` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Trainer`
--

LOCK TABLES `Trainer` WRITE;
/*!40000 ALTER TABLE `Trainer` DISABLE KEYS */;
INSERT INTO `Trainer` VALUES (1,'Lonie','Beatty',248,98,'M',1298),(2,'Anya','Corwin',256,1,'M',555),(3,'Dana','Mueller',438,681,'M',1133),(4,'Rickie','Langworth',498,1,'M',1672),(5,'Rebeka','Johns',304,500801,'M',1069),(6,'Osvaldo','Casper',273,0,'F',2199),(7,'Burley','Friesen',399,2147483647,'M',1020);
/*!40000 ALTER TABLE `Trainer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vehicle`
--

DROP TABLE IF EXISTS `Vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `available` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vehicle`
--

LOCK TABLES `Vehicle` WRITE;
/*!40000 ALTER TABLE `Vehicle` DISABLE KEYS */;
INSERT INTO `Vehicle` VALUES (1,'aut','Moen-Goldner',0),(2,'non','Sawayn Ltd',1),(3,'laboriosam','Jacobs-Kohler',1),(4,'in','Will-Lang',0),(5,'esse','Howell, O\'Keefe and Schaefer',1),(6,'atque','Predovic, Littel and Gislason',1),(7,'est','Crooks Ltd',0),(8,'sit','Hayes, Tillman and Kertzmann',0),(9,'error','Wunsch-Prosacco',1),(10,'eaque','Senger-Cormier',1),(11,'voluptates','Collins Ltd',1),(12,'voluptates','Metz-Kozey',0),(13,'officiis','Senger, Dach and Shields',1),(14,'eveniet','Breitenberg-Mraz',1),(15,'ut','Boyer Ltd',1),(16,'exercitationem','Morissette Group',1),(17,'corporis','Spencer, Jenkins and Brakus',1),(18,'sit','Lemke-Dicki',0),(19,'totam','Keeling and Sons',0),(20,'ullam','McCullough, Skiles and Osinski',0),(21,'qui','Herman Ltd',0),(22,'nihil','Volkman, Osinski and Altenwerth',0),(23,'vel','Reinger-Waelchi',0),(24,'dicta','McCullough, Fritsch and Keebler',1),(25,'qui','Leannon Group',1),(26,'necessitatibus','Abshire, Veum and Barrows',1),(27,'dolorem','Hartmann, Reinger and Gottlieb',1),(28,'minus','Connelly, Schimmel and Harris',1),(29,'rerum','Thiel, Kihn and Schuppe',0),(30,'et','Predovic-Prosacco',1),(31,'impedit','Kerluke, Bahringer and Nicolas',1),(32,'hic','Hessel-Bode',0),(33,'amet','Rohan-Gleichner',0),(34,'adipisci','Simonis PLC',1),(35,'explicabo','Satterfield, Flatley and Corkery',0),(36,'aut','Crist, Langworth and Rogahn',0),(37,'architecto','Mueller-Wisoky',1),(38,'cupiditate','Wintheiser-Hessel',1),(39,'est','Klocko-Swift',1),(40,'modi','Smitham-Fay',1),(41,'nihil','Kreiger LLC',1),(42,'aut','DuBuque-Huels',1),(43,'deleniti','Abbott, Prohaska and Kilback',0),(44,'delectus','Runte, Hills and Dare',1),(45,'architecto','Hodkiewicz Inc',0),(46,'illum','Becker, Donnelly and Runte',1),(47,'vitae','Mills Ltd',0),(48,'sed','Bogan, McGlynn and Luettgen',0),(49,'nostrum','Bergnaum and Sons',1),(50,'porro','Daniel, Rempel and Borer',1);
/*!40000 ALTER TABLE `Vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vehicle_Building`
--

DROP TABLE IF EXISTS `Vehicle_Building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vehicle_Building` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Vehicle_plate` int(11) NOT NULL,
  `Building_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Vehicle_Building` (`Building_id`),
  KEY `Vehicle_association_1` (`Vehicle_plate`),
  CONSTRAINT `Vehicle_Building` FOREIGN KEY (`Building_id`) REFERENCES `Building` (`id`),
  CONSTRAINT `Vehicle_association_1` FOREIGN KEY (`Vehicle_plate`) REFERENCES `Vehicle` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vehicle_Building`
--

LOCK TABLES `Vehicle_Building` WRITE;
/*!40000 ALTER TABLE `Vehicle_Building` DISABLE KEYS */;
INSERT INTO `Vehicle_Building` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5),(6,6,6),(7,7,7),(8,8,8),(9,9,9),(10,10,10),(11,11,11),(12,12,12),(13,13,13),(14,14,14),(15,15,15),(16,16,16),(17,17,17),(18,18,18),(19,19,19),(20,20,20),(21,21,21),(22,22,22),(23,23,23),(24,24,24),(25,25,25);
/*!40000 ALTER TABLE `Vehicle_Building` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-11 21:43:24
